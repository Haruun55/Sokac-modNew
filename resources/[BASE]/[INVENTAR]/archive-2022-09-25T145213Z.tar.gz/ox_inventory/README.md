<h1 align='center'><a href='https://overextended.github.io/ox_inventory/'>Documentation</a></h1><p align='center'>Click the link above for information on setup, installation, and improving compatibility with other resources.

<h2 align='center'>This project is still a work-in-progress - only recommended for competent developers.
<br><br>
<img src='https://user-images.githubusercontent.com/65407488/146972026-704f9932-ee4a-43e3-acb3-7e9a8b9eda04.png'/></h2>



<br><br><br><h3 align='center'>Legal Notices</h2>
<table><tr><td>
Ox Inventory for ESX Legacy  

Copyright © 2021  Overextended


This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.  


This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.  


You should have received a copy of the GNU General Public License
along with this program.  
If not, see <https://www.gnu.org/licenses/>
</td></tr>
<tr><td>
This resource is a completely new implementation of linden_inventory, which started as a fork of <a href='https://github.com/hsnnnnn/hsn-inventory/tree/9feef47269dbf8271f9e6b477188da88c15758e3'>hsn-inventory</a>
</td></td></table>


<p align='center'><a href='https://discord.io/overextended'>Discord</a></p>
